module.exports={reactStrictMode:true}
